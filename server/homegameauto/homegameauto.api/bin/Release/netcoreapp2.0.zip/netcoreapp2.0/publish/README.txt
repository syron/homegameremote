﻿1. Flytta filerna till en katalog i din IIS
2. Öppna appsettings.json och ändra följande appsettings och ändra till lämplig katalog
2. a) GameSettings:GameConsolesFolder, där filen gameconsoles.json ligger
2. b) GameSettings:GamesFolder, där filen games.json ligger
3. Done, nu kan du navigera till http://localhost/dinwebbpath/games för att testa